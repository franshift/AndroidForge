# Amber Rock Charge (prototipo Android)

Proyecto inicial Kotlin para Android Studio. Lee el porcentaje real mediante `ACTION_BATTERY_CHANGED` mientras la pantalla de la app está abierta y dibuja una roca giratoria sobre un anillo color ámbar.

## Abrir
1. Instalar Android Studio en una computadora.
2. Abrir esta carpeta como proyecto.
3. Esperar la sincronización de Gradle.
4. Conectar el Samsung S24 Ultra con depuración USB habilitada.
5. Ejecutar `app`.

## Alcance y limitaciones
- El porcentaje leído es real mientras la actividad está abierta.
- La animación es dibujada en tiempo real y usa ámbar en lugar de azul.
- Este es código fuente, no un APK instalado.
- Android 10 y posteriores restringen que una app abra una pantalla completa por sí sola cuando se conecta el cargador. El receptor incluido no fuerza esa apertura. Para una versión distribuible hay que implementar una notificación visible y una opción de inicio/visualización que el usuario habilite, respetando las reglas de Android y One UI.
- La hora del teléfono puede añadirse a la interfaz en la siguiente iteración.
