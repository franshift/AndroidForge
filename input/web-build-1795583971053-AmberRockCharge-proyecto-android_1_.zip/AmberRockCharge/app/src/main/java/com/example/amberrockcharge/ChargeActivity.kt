package com.example.amberrockcharge

import android.app.Activity
import android.os.BatteryManager
import android.os.Bundle
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.view.View
import android.view.WindowManager
import kotlin.math.*

class ChargeActivity : Activity() {
    private lateinit var scene: ChargeView
    private val batteryReceiver = object : android.content.BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            scene.updateBattery(intent)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)
        scene = ChargeView(this)
        setContentView(scene)
        registerReceiver(batteryReceiver, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    }

    override fun onDestroy() {
        try { unregisterReceiver(batteryReceiver) } catch (_: Exception) {}
        super.onDestroy()
    }
}

class ChargeView(context: Context) : View(context) {
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(5, 6, 8) }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textAlign = Paint.Align.CENTER; typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL) }
    private val amber = Color.rgb(255, 174, 66)
    private val earth = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(111, 75, 43); style = Paint.Style.STROKE; strokeWidth = 17f }
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(54, 43, 31); style = Paint.Style.STROKE; strokeWidth = 5f }
    private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = amber; style = Paint.Style.STROKE; strokeWidth = 5f; strokeCap = Paint.Cap.ROUND }
    private val rock = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(183, 164, 139); style = Paint.Style.FILL }
    private var level = 0
    private var charging = false
    private var rotation = 0f
    private val bounds = RectF()

    fun updateBattery(intent: Intent) {
        level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, 0)
        val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bg)
        val cx = width / 2f
        val cy = height * .43f
        val radius = min(width, height) * .31f
        bounds.set(cx-radius, cy-radius, cx+radius, cy+radius)
        earth.setShadowLayer(5f, 0f, 0f, Color.rgb(126, 75, 30))
        canvas.drawCircle(cx, cy, radius, earth)
        canvas.drawCircle(cx, cy, radius, track)
        arc.strokeWidth = 6f
        arc.setShadowLayer(14f, 0f, 0f, amber)
        canvas.drawArc(bounds, -90f, 360f * level / 100f, false, arc)
        canvas.save()
        canvas.rotate(rotation, cx, cy)
        val rx = cx
        val ry = cy - radius
        val path = Path().apply {
            moveTo(rx-18, ry+5); lineTo(rx-9, ry-17); lineTo(rx+7, ry-22)
            lineTo(rx+20, ry-5); lineTo(rx+13, ry+13); lineTo(rx-8, ry+17); close()
        }
        canvas.drawPath(path, rock)
        val crack = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(91, 65, 45); strokeWidth = 2f }
        canvas.drawLine(rx-4, ry-10, rx+3, ry+2, crack)
        canvas.drawLine(rx+3, ry+2, rx-5, ry+10, crack)
        canvas.restore()
        text.textSize = 57f
        canvas.drawText("$level%", cx, cy+17f, text)
        text.textSize = 13f
        text.color = amber
        canvas.drawText(if (charging) "CARGANDO" else "BATERÍA", cx, cy+48f, text)
        text.color = Color.LTGRAY
        text.textSize = 15f
        canvas.drawText("AMBER ROCK CHARGE", cx, height*.82f, text)
        text.textSize = 12f
        canvas.drawText("La roca abre camino", cx, height*.86f, text)
        rotation = (rotation + 2.2f) % 360f
        postInvalidateDelayed(33)
    }
}
