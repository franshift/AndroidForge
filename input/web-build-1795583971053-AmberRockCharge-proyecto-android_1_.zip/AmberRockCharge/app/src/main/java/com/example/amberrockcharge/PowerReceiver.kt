package com.example.amberrockcharge

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class PowerReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        // Android may restrict opening an Activity from the background.
        // The app records no data; open it manually to see the live charging display.
        if (intent.action == Intent.ACTION_POWER_CONNECTED) {
            val launch = context.packageManager.getLaunchIntentForPackage(context.packageName)
            // Deliberately do not force-launch over another app. Android 10+ restricts this.
            // A production release should use a user-enabled notification/overlay flow.
        }
    }
}
